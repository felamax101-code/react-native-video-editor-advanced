import type { CompressOptions, CompressResult, ExtractAudioOptions, ExtractAudioResult, FileValidationResult, FrameExtractionOptions, FrameResult, GifOptions, GifResult, MergeOptions, MergeResult, MixAudioOptions, MixAudioResult, SaveToDocumentsResult, SaveToPhotoResult, ShareResult, TrimOptions, TrimResult, Spec } from './NativeVideoTrim';
import type { EditorOptions } from './types';
/**
 * The native module. Call the named functions ({@link showEditor},
 * {@link trim}, ...) for everything else; use the default export to subscribe
 * to editor events on the New Architecture. Each `on*` emitter takes a listener
 * and returns a subscription with `remove()`. Payloads are described in
 * {@link VideoTrimEventMap}.
 *
 * @example
 * ```ts
 * import VideoTrim from 'react-native-video-trim';
 *
 * const sub = VideoTrim.onFinishTrimming(({ outputPath, duration }) => {
 *   console.log(outputPath, duration);
 * });
 * // later
 * sub.remove();
 * ```
 */
declare const VideoTrim: Spec;
/**
 * Open the full-screen trimmer editor for a video or audio file.
 *
 * The call returns immediately. Follow what happens in the editor through the
 * events on the default export (New Architecture) or the `"VideoTrim"` native
 * event (Old Architecture); see {@link VideoTrimEventMap}.
 *
 * @param filePath - Local path, `file://` URI or (with the `https` FFmpegKit
 *   package) an HTTPS URL of the media to edit.
 * @param config - Editor options. Every field is optional.
 *
 * @example
 * ```ts
 * import { showEditor } from 'react-native-video-trim';
 *
 * showEditor(videoUri, {
 *   maxDuration: 30_000, // milliseconds
 *   saveToPhoto: true,
 * });
 * ```
 */
export declare function showEditor(filePath: string, config?: EditorOptions): void;
/**
 * List every output file the library has produced and not yet deleted, in both
 * the persistent and the cache output directories.
 *
 * @returns Absolute paths of the files.
 */
export declare function listFiles(): Promise<string[]>;
/**
 * Delete every output file the library has produced, in both the persistent
 * and the cache output directories.
 *
 * @returns The number of files deleted.
 */
export declare function cleanFiles(): Promise<number>;
/**
 * Delete one output file. On Android, only files inside the library's own
 * output directories can be deleted; other paths resolve `false`.
 *
 * @param filePath - Absolute path of the file, as returned by another API.
 * @returns `true` when the file was deleted (or, on Android, did not exist).
 * @throws Error synchronously when `filePath` is empty.
 */
export declare function deleteFile(filePath: string): Promise<boolean>;
/**
 * Give the open editor a song. Call this after the user picks one from your own picker.
 */
export declare function addSong(path: string, title: string, durationMs: number): void;
/**
 * Close the editor if it is open.
 */
export declare function closeEditor(): void;
/**
 * Check whether a file is a playable audio or video file.
 *
 * @param url - Local path or URL of the file.
 * @returns Whether the file is valid, its type and its duration.
 *
 * @example
 * ```ts
 * const { isValid, fileType, duration } = await isValidFile(uri);
 * ```
 */
export declare function isValidFile(url: string): Promise<FileValidationResult>;
/**
 * Trim a video or audio file without showing any UI.
 *
 * @param url - Local path or URL of the media.
 * @param options - Trim range and output options. Times are in milliseconds.
 * @returns The trimmed range and the output path.
 *
 * @example
 * ```ts
 * const { outputPath } = await trim(videoUri, {
 *   startTime: 5_000,
 *   endTime: 25_000,
 * });
 * ```
 */
export declare function trim(url: string, options: Partial<TrimOptions>): Promise<TrimResult>;
/**
 * Extract a single frame from a video as a JPEG or PNG image.
 *
 * @param url - Local path of the video.
 * @param options - Timestamp, format and size of the frame.
 * @returns The path of the image, written to the cache directory.
 *
 * @example
 * ```ts
 * const { outputPath } = await getFrameAt(videoUri, { time: 5_000, maxWidth: 640 });
 * ```
 */
export declare function getFrameAt(url: string, options?: Partial<FrameExtractionOptions>): Promise<FrameResult>;
/**
 * Extract the audio track of a video into a separate audio file.
 *
 * @param url - Local path of the video.
 * @param options - Output format. Defaults to `m4a` (AAC).
 * @returns The path and duration of the audio file, written to the cache directory.
 *
 * @example
 * ```ts
 * const { outputPath, duration } = await extractAudio(videoUri);
 * ```
 */
export declare function extractAudio(url: string, options?: Partial<ExtractAudioOptions>): Promise<ExtractAudioResult>;
/**
 * Re-encode a video to make it smaller.
 *
 * @param url - Local path of the video.
 * @param options - Quality preset, or explicit bitrate, size and frame rate.
 * @returns The path of the compressed video, written to the cache directory.
 *
 * @example
 * ```ts
 * const { outputPath } = await compress(videoUri, { quality: 'medium' });
 * ```
 */
export declare function compress(url: string, options?: Partial<CompressOptions>): Promise<CompressResult>;
/**
 * Convert a segment of a video to an animated GIF.
 *
 * @param url - Local path of the video.
 * @param options - Segment, frame rate and width of the GIF.
 * @returns The path of the GIF, written to the cache directory.
 *
 * @example
 * ```ts
 * const { outputPath } = await toGif(videoUri, { startTime: 2_000, endTime: 7_000, fps: 15, width: 320 });
 * ```
 */
export declare function toGif(url: string, options?: Partial<GifOptions>): Promise<GifResult>;
/**
 * Concatenate several clips into one file, in order. Clips may differ in
 * resolution, frame rate and codec; they are converted to match the first
 * clip. Only local files are supported.
 *
 * @param urls - Local paths of the clips, in playback order.
 * @param options - Output options.
 * @returns The path and duration of the merged file, written to the cache directory.
 * @throws Error synchronously when `urls` is empty.
 *
 * @example
 * ```ts
 * const { outputPath } = await merge([clip1, clip2, clip3]);
 * ```
 */
export declare function merge(urls: string[], options?: Partial<MergeOptions>): Promise<MergeResult>;
/**
 * Mix (or replace) an external audio track, such as background music or a
 * voice-over, into a video. The video stream is copied unchanged, so only the
 * audio is re-encoded. Only local files are supported.
 *
 * @param videoPath - Local path of the source video.
 * @param audioPath - Local path of the audio to mix in.
 * @param options - Volumes, start offset and looping.
 * @returns The path and duration of the output video, written to the cache directory.
 * @throws Error synchronously when either path is empty.
 *
 * @example
 * ```ts
 * // Replace the original audio with a voice-over
 * const { outputPath } = await mixAudio(videoPath, voiceOverPath, {
 *   originalAudioVolume: 0,
 * });
 * ```
 */
export declare function mixAudio(videoPath: string, audioPath: string, options?: Partial<MixAudioOptions>): Promise<MixAudioResult>;
/**
 * Save an image or video to the device's photo library. Requires photo
 * library permission.
 *
 * @param filePath - Absolute path of the file.
 * @returns Whether the file was saved.
 * @throws Error synchronously when `filePath` is empty.
 */
export declare function saveToPhoto(filePath: string): Promise<SaveToPhotoResult>;
/**
 * Let the user save a file to a location of their choice with the system
 * document picker.
 *
 * @param filePath - Absolute path of the file.
 * @returns Whether the file was saved.
 * @throws Error synchronously when `filePath` is empty.
 */
export declare function saveToDocuments(filePath: string): Promise<SaveToDocumentsResult>;
/**
 * Open the system share sheet for a file.
 *
 * @param filePath - Absolute path of the file. On Android it must be inside
 *   the library's output directories.
 * @returns Whether the user completed the share.
 * @throws Error synchronously when `filePath` is empty.
 */
export declare function share(filePath: string): Promise<ShareResult>;
export type { BaseOptions, CompressOptions, CompressResult, EditorConfig, ExtractAudioOptions, ExtractAudioResult, FileValidationResult, FrameExtractionOptions, FrameResult, GifOptions, GifResult, MergeOptions, MergeResult, MixAudioOptions, MixAudioResult, SaveToDocumentsResult, SaveToPhotoResult, ShareResult, Spec, TrimOptions, TrimResult, } from './NativeVideoTrim';
export type { EditorOptions, ErrorCode, FinishTrimmingEvent, LoadEvent, LogEvent, StatisticsEvent, VideoTrimErrorEvent, VideoTrimEvent, VideoTrimEventMap, VideoTrimEventName, } from './types';
export default VideoTrim;
//# sourceMappingURL=index.d.ts.map