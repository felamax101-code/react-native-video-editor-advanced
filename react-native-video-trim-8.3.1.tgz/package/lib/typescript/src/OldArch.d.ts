export * from './NativeVideoTrim';
declare const VideoTrim: any;
export default VideoTrim;
//# sourceMappingURL=OldArch.d.ts.map